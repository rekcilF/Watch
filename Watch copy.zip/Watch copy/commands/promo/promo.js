const commando = require('discord.js-commando')

class DiceRollCommand extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'botinfo',
            group: 'testing',
            memberName: 'botinfo',
            description: 'botinfo'
        });
    }

    async run(message, args) {
        let github = 'github link'
        let discordServer = 'https://discord.gg/6sPPXMX'
        var botinfo = message.channel.sendMessage ('This bot is made by rekcilF and Android gitHub: ' + github + 'Offical Discord Server: ' + discordServer)
    }
}

module.exports = DiceRollCommand;